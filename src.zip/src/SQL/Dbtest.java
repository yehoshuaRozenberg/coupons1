package SQL;

import Beans.Company;
import DBDAO.CompanysDBDAO;
import Fasade.CompanyFasade;
import Fasade.LoginManager;
import Fasade.clientTipe;

import java.util.ArrayList;

public class Dbtest {
    public static void main(String[] args) {
        DBManager.dropdb();


        DBManager.createDataBase();
        DBManager.createTables();


        Company company1 =new Company("superMarket","super@super","123456");
        //companysDBDAO.addCompany(company1);

        /*Company company2 =new Company("Market","market@super","7891010");
        companysDBDAO.addCompany(company2);

        System.out.println(companysDBDAO.getOneCompany(2));

        ArrayList<Company> companies1= companysDBDAO.getAllCompanys();
        companies1.forEach(System.out::println);

        companysDBDAO.deleteCompany(2);

        companies1.get(0).setEmail("david");
        System.out.println(companies1.get(0));
        companysDBDAO.updateCompany(companies1.get(0));

        ArrayList<Company> companies2= companysDBDAO.getAllCompanys();
        companies2.forEach(System.out::println);
*/


        //DBManager.dropdb();

    }

}
