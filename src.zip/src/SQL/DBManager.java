package SQL;

import java.sql.SQLException;

import SQL.DBUtils;

public class DBManager {
    //connection DB
    public static final String URL = "jdbc:mysql://localhost:3306?createDatabaseIfNotExist=FALSE";
    public static final String USER_NAME = "root";
    public static final String PASSWORD = "12345678";

    //create & drop database
    private static final String CREATE_DB = "CREATE SCHEMA if not exists couponsDB";
    private static final String DROP_DB = "DROP schema if exists `couponsdb`";

    //create & drop tables
    private static final String CREATE_TABLE_COMPANY =
            "CREATE TABLE if not exists`couponsDB`.`companies`" +
                    "(`id` INT NOT NULL AUTO_INCREMENT," +
                    "`name` VARCHAR(45) NULL," +
                    "`email` VARCHAR(45) NULL," +
                    "`password` VARCHAR(45) NULL," +
                    "PRIMARY KEY (`id`));";

    private static final String CREATE_TABLE_CUSTOMERS =
            "CREATE TABLE if not exists `couponsDB`.`customers` "
                    + "(`id` INT NOT NULL AUTO_INCREMENT," +
                    "`FIRST_NAME` VARCHAR(45) NULL," +
                    "`LAST_NAME` VARCHAR(45) NULL," +
                    "`EMAIL` VARCHAR(45) NULL," +
                    "`PASSWORD` VARCHAR(45) NULL," +
                    "PRIMARY KEY (`id`));";

    private static final String CREATE_TABLE_CATAGORIES =
            "CREATE TABLE if not exists`couponsDB`.`categories`" +
                    "(`id` INT NOT NULL AUTO_INCREMENT," +
                    "`name` VARCHAR(45) NULL," +
                    "PRIMARY KEY (`id`));";

    private static final String CREATE_TABLE_COUPONS = //todo: 2 new foreign keys company and category + cascade
            "CREATE TABLE if not exists`couponsDB`.`coupons` " +
                    "(`id` INT NOT NULL AUTO_INCREMENT," +
                    "`ID_COMPANY` INT NULL," +
                    "`iD_CATEGORY` INT NULL," +
                    "`title` VARCHAR(45) NULL," +
                    "`DESCRIPTION` VARCHAR(45) NULL," +
                    "`START_DATE` DATE NULL," +
                    "`END_DATE` DATE NULL," +
                    "`AMOUNT` INT NULL," +
                    "`PRICE` DOUBLE NULL," +
                    "`IMAGE` VARCHAR(45) NULL," +
                    "PRIMARY KEY (`id`));";


    private static final String CREATE_TABLE_CUSTOMERS_VS_COUPONS =
            "CREATE TABLE if not exists `couponsDB`.`customers_vs_coupons` " +
                    "(`customer_id` INT NOT NULL," +
                    "`coupon_id` INT NOT NULL," +
                    " PRIMARY KEY (`customer_id`, `coupon_id`)," +
                    " INDEX `coupon_id_idx` (`coupon_id` ASC) VISIBLE," +
                    " FOREIGN KEY (`customer_id`)" +
                    " REFERENCES `customers` (`id`),"+
                    " FOREIGN KEY (`coupon_id`)" +
                    " REFERENCES `coupons` (`id`) ON DELETE CASCADE)";
   // "ALTER TABLE (`customers_vs_coupons`) ADD FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE";



    public static void createDataBase() {
        try {
            DBUtils.runSimpleQuery(CREATE_DB);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void createTables() {
        try {
            DBUtils.runSimpleQuery(CREATE_TABLE_COMPANY);
            DBUtils.runSimpleQuery(CREATE_TABLE_CUSTOMERS);
            DBUtils.runSimpleQuery(CREATE_TABLE_CATAGORIES);
            DBUtils.runSimpleQuery(CREATE_TABLE_COUPONS);
            DBUtils.runSimpleQuery(CREATE_TABLE_CUSTOMERS_VS_COUPONS);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void dropdb() {
        try {
            DBUtils.runSimpleQuery(DROP_DB);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
