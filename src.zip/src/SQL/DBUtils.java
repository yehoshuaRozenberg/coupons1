package SQL;

import Beans.Company;
import Beans.Coupon;
import DBDAO.CouponsDBDAO;
import Fasade.clientTipe;
import SQL.ConnectionPool;

import java.sql.*;
import java.util.ArrayList;
import java.util.Map;

public class DBUtils {
    /*public static PreparedStatement preparedStatement(String sql,Map<Integer,Object> params) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = connection.prepareStatement(sql);
   /* try {
        connection = ConnectionPool.getInstance().getConnection();
        statement = connection.prepareStatement(sql);
     */   //our simple way
  /*      params.forEach((key, value) -> {
            try {
                if (value instanceof Integer) {
                    statement.setInt(key, (int) value);
                } else if (value instanceof String) {
                    statement.setString(key, String.valueOf(value));
                } else if (value instanceof Date) {
                    statement.setDate(key, (Date) value);
                } else if (value instanceof Boolean) {
                    statement.setBoolean(key, (Boolean) value);
                } else if (value instanceof Double) {
                    statement.setDouble(key, (Double) value);
                } else if (value instanceof Float) {
                    statement.setFloat(key, (Float) value);
                } else if (value instanceof Timestamp) {
                    statement.setTimestamp(key, (Timestamp) value);
                }
            } catch (SQLException err) {
                System.out.println("Error in sql :" + err.getMessage());
            }
        });

/*       // statement.execute();
    } catch (InterruptedException | SQLException e) {
        System.out.println("Error in executing sql");
        return false;
    } finally {
        ConnectionPool.getInstance().returnConnection(connection);
    }
        return true;
}try {
            //take a connection for connection pool.
            connection = ConnectionPool.getInstance().getConnection();
            //run the sql command
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();
        } catch (InterruptedException | SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionPool.getInstance().returnConnection(connection);
        }
    }
    */

  /*      return statement;
    }
*/
    /*
    public static void ssss(String aaa) {
        Map<Integer,Object> hh=null;
        hh.put(1,"ppp");

        try {
            runSimpleQuery(preparedStatement(aaa,hh));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    */
    public static void runSimpleQuery(String sql) throws SQLException {
        Connection connection = null;
        try {
            //take a connection for connection pool.
            connection = ConnectionPool.getInstance().getConnection();
            //run the sql command
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();
        } catch (InterruptedException | SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionPool.getInstance().returnConnection(connection);
        }
    }

    public static boolean runBetterQuery(String query, Map<Integer, Object> params) throws SQLException {
        Connection connection = null;
        try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            //our simple way
            params.forEach((key, value) -> {
                try {
                    if (value instanceof Integer) {
                        statement.setInt(key, (int) value);
                    } else if (value instanceof String) {
                        statement.setString(key, String.valueOf(value));
                    } else if (value instanceof Date) {
                        statement.setDate(key, (Date) value);
                    } else if (value instanceof Boolean) {
                        statement.setBoolean(key, (Boolean) value);
                    } else if (value instanceof Double) {
                        statement.setDouble(key, (Double) value);
                    } else if (value instanceof Float) {
                        statement.setFloat(key, (Float) value);
                    } else if (value instanceof Timestamp) {
                        statement.setTimestamp(key, (Timestamp) value);
                    }
                } catch (SQLException err) {
                    System.out.println("Error in sql :" + err.getMessage());
                }
            });
            statement.execute();
        } catch (InterruptedException | SQLException e) {
            System.out.println("Error in executing sql");
            return false;
        } finally {
            ConnectionPool.getInstance().returnConnection(connection);
        }
        return true;
    }

    //to get everything from DB by index, '0' for all
    public static ResultSet getFromDB(int id, String getMessage) {
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(getMessage);
            if (id != 0) {
                statement.setInt(1, id);
            }
            resultSet = statement.executeQuery();
        } catch (SQLException | InterruptedException err) {
            System.out.println("Error in sql :" + err.getMessage());
        } finally {
            try {
                ConnectionPool.getInstance().returnConnection(connection);
            } catch (SQLException err) {
                System.out.println("Error in finally:" + err.getMessage());
            }
        }
        return resultSet;
    }

    public static int getIdByEmail(String table, String email) {
        String GET_ID_BY_NAME = "SELECT id FROM `couponsDB`.table WHERE email= ?";
        int id=0;
        Connection connection = null;
        String get= GET_ID_BY_NAME.replaceAll("table", table);
        try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(get);
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                id = resultSet.getInt(1);
                break;
            }
        } catch (SQLException | InterruptedException err) {
            System.out.println("Error in sql :" + err.getMessage());
        } finally {
            try {
                ConnectionPool.getInstance().returnConnection(connection);
            } catch (SQLException err) {
                System.out.println("Error in finally:" + err.getMessage());
            }
        }
        return id;
    }

    public static void deleteById(int id, String delet) {
        Connection connection = null;
        try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(delet);
            statement.setInt(1, id);
            statement.execute();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                ConnectionPool.getInstance().returnConnection(connection);
            } catch (SQLException err) {
                System.out.println("Error in finally:" + err.getMessage());
            }
        }
    }

    public static boolean isExist(String message, String row, String chek) {
        boolean res = false;
        Connection connection = null;
        try {
            message = message.replaceAll("zz", row);
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(message);
            //statement.setString(1, row);
            statement.setString(1, chek);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                if (resultSet.getInt(1) != 0) {
                    res = true;
                }
            }
        } catch (InterruptedException e) {
            System.out.println("error" + e);
            ;
        } catch (SQLException err) {
            System.out.println("Error" + err);
            ;
        } finally {
            try {
                ConnectionPool.getInstance().returnConnection(connection);
            } catch (SQLException err) {
                System.out.println("Error in finally:" + err.getMessage());
            }
        }
        return res;
    }

    public static boolean logInChek(String email, String password, String name) {
        boolean res = false;
            String LOG_IN = "SELECT EXISTS (SELECT 1 FROM `couponsDB`.Table WHERE email =? and password=? limit 1) ;";
            String log = LOG_IN.replaceFirst("Table", name);
            Connection connection = null;
            try {
                connection = ConnectionPool.getInstance().getConnection();
                PreparedStatement statement = connection.prepareStatement(log);
                statement.setString(1, email);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    if (resultSet.getInt(1) != 0) {
                        res = true;
                    }
                }
            } catch (InterruptedException e) {
                System.out.println("error" + e);
                ;
            } catch (SQLException err) {
                System.out.println("Error" + err);
                ;
            } finally {
                try {
                    ConnectionPool.getInstance().returnConnection(connection);
                } catch (SQLException err) {
                    System.out.println("Error in finally:" + err.getMessage());
                }
            }

        return res;
    }

    //public static ArrayList<Coupon> getAllCouponsByTableAndParameter(String message, int id, double num) {

    /*

            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            connection.
            //our simple way
            params.forEach((key, value) -> {
                try {
                    if (value instanceof Integer) {
                        statement.setInt(key, (int) value);
                    } else if (value instanceof String) {
                        statement.setString(key, String.valueOf(value));
                    } else if (value instanceof Date) {
                        statement.setDate(key, (Date) value);
                    } else if (value instanceof Boolean) {
                        statement.setBoolean(key, (Boolean) value);
                    } else if (value instanceof Double) {
                        statement.setDouble(key, (Double) value);
                    } else if (value instanceof Float) {
                        statement.setFloat(key, (Float) value);
                    } else if (value instanceof Timestamp) {
                        statement.setTimestamp(key, (Timestamp) value);

                    }
                } catch (SQLException err) {
                    System.out.println("Error in sql :" + err.getMessage());
                }
            });
            statement.execute();
        } catch (InterruptedException | SQLException e) {
            System.out.println("Error in executing sql");
            return false;
        } finally {
            ConnectionPool.getInstance().returnConnection(connection);
        }
        return true;

    }*/
}


