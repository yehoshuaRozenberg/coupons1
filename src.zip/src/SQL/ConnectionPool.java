package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Stack;

public class ConnectionPool {
    private static ConnectionPool instance = null;
    private static final int NUM_OF_CONNECTIONS = 10;
    private Stack<Connection> connectionStack = new Stack<>();
    //private static int a=0;
    //private static int b=0;

    //א"א לבנות את המחלקה הזו דרך הקונסטרקטור שלה כי הוא private. אפשר רק לגשת למתודות
    // רק ע"י מתודה getInstance ניתן לקבל את המופע הבודד שקיים או שזה יוצר חדש אם לא קיים
    //המופע הבודד הזה הולך לבנאי שקורא למתודה שפותחת את כל הקונקשנים
    //ואז אחרי זה כותבים getConnection. שזה בעצם נותן אחד מה10 קונקשנים ל

    private ConnectionPool() throws SQLException {
        openAllConnections();
    }

    public void openAllConnections() throws SQLException {
        for (int index = 1; index <= NUM_OF_CONNECTIONS; index += 1) {
            try {
                Connection connection = DriverManager.getConnection(DBManager.URL, DBManager.USER_NAME, DBManager.PASSWORD);
                connectionStack.push(connection);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }

    public static ConnectionPool getInstance() throws SQLException {
        if (instance == null) {
            synchronized (ConnectionPool.class) {
                if (instance == null) {
                    instance = new ConnectionPool();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() throws InterruptedException {
        synchronized (connectionStack) {
            if (connectionStack.isEmpty()) {
                try {
                    connectionStack.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        //a+=1;
        //System.out.println(a);
        return connectionStack.pop();

    }

    public void returnConnection(Connection connection) {
        synchronized (connectionStack) {
            connectionStack.push(connection);
            connectionStack.notify();
        }
        //b+=1;
        //System.out.println(b);
    }

}
