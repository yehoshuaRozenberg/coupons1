package Threds;
/*
public class CouponScannerSystem implements Runnable{
    final private static String COUPON_DELETE_BY_TIME =


    public CouponScannerSystem() {
    }

    @Override
    public void run() {
        System.out.println("Starting thread");
        while(true){
            //checkDeadline();
            checkDeadLine();
            try {
                Thread.sleep(60*1000);
            } catch (InterruptedException e) {
                System.out.println("TasksThread has been stopped!");
            }
        }

    }
    public void checkDeadLine(){
        LocalDateTime now = LocalDateTime.now();
        for (Task task : tasks) {
            if (task.getDeadLined().isAfter(now) && !task.isAlertPopped()) {
                System.out.println("DEAD LINE ALERT : " + task);
                task.setAlertPopped(true);
            }
        }
    }
}



    @Override
    public void run() {

    }
}*/
