package Beans;

public enum Catagory {
    FOOD,
    ELECTRICITY,
    RESTRAURANT,
    VACATION

  /*  food("food"),
    electricity("electricity"),
    restaurant("restaurant"),
    vacation("vacation");

    private String details;
    private int categoryId;

    public Category(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    Category(String details) {
        this.details = details;
    }

    public String getDetails() {
        return details;
    }
} */
}
