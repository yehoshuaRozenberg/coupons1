package Testers;

import Beans.Company;
import DBDAO.CompanysDBDAO;
import Fasade.AdminFasade;

public class AdminTester {


}
