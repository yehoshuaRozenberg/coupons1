package Testers;

import Beans.Catagory;
import Beans.Company;
import Beans.Coupon;
import Beans.Customer;
import DBDAO.CompanysDBDAO;
import DBDAO.CouponsDBDAO;
import DBDAO.CustomersDBDAO;
import Fasade.*;
import SQL.DBManager;

import java.sql.Date;

public class MainTester {
    public static void main(String[] args) {


        DBManager.dropdb(); //todo if exists

        DBManager.createDataBase();
        DBManager.createTables();

/*
        AdminFasade adminFasade = new AdminFasade("admin");
        Company company1 = new Company("superMarket", "super@super", "123456");
        adminFasade.addNewCompany(company1);

        Company company2 = new Company("Market", "market@super", "7891010");
        adminFasade.addNewCompany(company2);

        adminFasade.addNewCompany(company1);
*/

        AdminFasade adminFasade = (AdminFasade) LoginManager.getInstance().logIn("admin@admin.com", "admin", clientTipe.Administrator);
        adminFasade.addNewCompany(new Company("superMarket", "super@super", "123456"));
        adminFasade.addNewCompany(new Company("Market", "market@super", "7891010"));
        adminFasade.addNewCompany(new Company("lising", "lising@gmail.com", "11111"));

        adminFasade.addNewCompany(new Company("superMarket", "super@super", "123456"));

        Company company1= adminFasade.getCompanyById(2);//todo: למה העדכון חברה נותן לחברה אי די 0, ולמה לא מעדכן לה את הסיסמה?
        company1.setPassword("789101112");
        adminFasade.updateCompany(company1);
        System.out.println(adminFasade.getCompanyById(2));
        System.out.println("=========================================");
        adminFasade.deleteCompany(1);
        System.out.println(adminFasade.getCompanyById(1));
        System.out.println(adminFasade.getCompanyById(2));
        adminFasade.getAllCompanys().forEach(System.out::println);

        adminFasade.addNewCustomer(new Customer("yossef","yzhak","yossef@yzhak","123456"));
        adminFasade.addNewCustomer(new Customer("david","ori","david@yzhak","987654"));
        adminFasade.addNewCustomer(new Customer("yehushua","rozenberg","yyyyyyy@rozenberg","9876"));
        adminFasade.deleteCustomer(1);
        System.out.println("////////////////////////////////////////");
        Customer customer1= adminFasade.getCustomerById(2);
        customer1.setPassword("777777");
        adminFasade.editCustomer(customer1);
        adminFasade.getAllCustomers().forEach(System.out::println);
        System.out.println(adminFasade.getCustomerById(2));

        System.out.println("******************************");  //todo how can i sign up as company if loginManager is singleton?
        CompanyFasade companyFasade=(CompanyFasade) LoginManager.getInstance().logIn("lising@gmail.com", "11111",clientTipe.Companies);
        Coupon coupon1= new Coupon(companyFasade.getId(), Catagory.ELECTRICITY,"pizza","yami pizza 1+1", Date.valueOf("2021-5-6"),Date.valueOf("2021-7-8"),100,50,"computer");
        Coupon coupon2= new Coupon(companyFasade.getId(), Catagory.FOOD,"SHNIZEL","yami shnizel 2+1", Date.valueOf("2021-5-6"),Date.valueOf("2021-7-8"),30,40,"computer");

        companyFasade.addNewCoupon(coupon1);
        companyFasade.addNewCoupon(coupon2);
        System.out.println(companyFasade.getAllCouponsOfCompany());
        Coupon coupon3 = companyFasade.getAllCouponsOfCompany().get(0);
        coupon3.setCatagory(Catagory.FOOD);
        companyFasade.updateCoupon(coupon3);
        System.out.println(companyFasade.getAllCouponsOfCompany());
        System.out.println(companyFasade.getCompanyDetails());//todo: למה בנתונים של החברה, מופיעה רשימת קופונים ריקה?

        System.out.println("**"+companyFasade.getAllCouponsUntilPrice(100));
        System.out.println(companyFasade.getAllCouponsUntilPrice(49));
        System.out.println("**"+companyFasade.getAllCouponsByCatagory(Catagory.ELECTRICITY));
        System.out.println(companyFasade.getAllCouponsByCatagory(Catagory.FOOD));

        System.out.println("******************************");
        CustomerFasade customerFasade1=(CustomerFasade) LoginManager.getInstance().logIn("yyyyyyy@rozenberg","9876",clientTipe.Customers);
        customerFasade1.purchaseCoupon(companyFasade.getAllCouponsOfCompany().get(0));
        customerFasade1.purchaseCoupon(companyFasade.getAllCouponsOfCompany().get(1));
        System.out.println(customerFasade1.getAllCouponsPurchased()); //todo: find why getting twice, maybe problem with inner join

        System.out.println("@@@@@@@@");
        //companyFasade.deleteCoupon(2);
        companyFasade.addNewCoupon(coupon2);
        companyFasade.addNewCoupon(coupon2);
        customerFasade1.purchaseCoupon(companyFasade.getAllCouponsOfCompany().get(3));

        System.out.println(customerFasade1.getAllCouponsPurchased());
        System.out.println(customerFasade1.getCustomerDetails());

        System.out.println("=========");

        CouponsDBDAO couponsDBDAO=new CouponsDBDAO();
        couponsDBDAO.deleteCouponPurchase(3,1);

        System.out.println(customerFasade1.getCustomerDetails());
        System.out.println("**"+customerFasade1.getCouponsPurchasedByCategory(Catagory.ELECTRICITY));
        System.out.println(customerFasade1.getCouponsPurchasedByCategory(Catagory.FOOD));
        System.out.println("**"+customerFasade1.getCouponsPurchasedUntilPrice(100));
        System.out.println(customerFasade1.getCouponsPurchasedUntilPrice(49));








    }
}
