package Fasade;

import Beans.Company;
import Beans.Customer;
import DBDAO.CompanysDBDAO;
import DBDAO.CustomersDBDAO;
import SQL.DBUtils;

import java.util.ArrayList;

public class AdminFasade extends clientFasade {
    private final String EMAIL = "admin@admin.com";
    private final String PASSWORD = "admin";
    private CompanysDBDAO companysDBDAO=new CompanysDBDAO();
    private CustomersDBDAO customersDBDAO=new CustomersDBDAO();

    public AdminFasade() {

    }

    public boolean logIn(String email, String password) {
        return email.equals(EMAIL) && password.equals(PASSWORD);
    }

    public void addNewCompany(Company company) {
        if (!companysDBDAO.isCompanyExists(company.getName(), company.getEmail())) {
            companysDBDAO.addCompany(company);
            System.out.println("company successfully added!");
        } else System.out.println("company name or email already exists, try enter a new one");
    }

    public void updateCompany(Company company) {
        companysDBDAO.updateCompany(company);
        System.out.println("company successfully updated!");
    }

    public void deleteCompany(int companyId) {
        companysDBDAO.deleteCompany(companyId);
        System.out.println("company successfully deleted!");
    }

    public ArrayList<Company> getAllCompanys() {
        ArrayList<Company> companies = companysDBDAO.getAllCompanys();
        //companies.forEach(System.out::println);
        return companies;
    }

    public Company getCompanyById(int companyId) {
        Company company=companysDBDAO.getOneCompany(companyId);
        System.out.print(company==null?"company dos not exists, returning null: ":"");
        return company;
    }

    public void addNewCustomer(Customer customer) {
        if (!customersDBDAO.isCustomerExists(customer.getEmail(), customer.getPassword())) {
            customersDBDAO.addCustomer(customer);
            System.out.println("customer successfully added!");
        } else System.out.println("customer email already exists, try enter a new one");
    }

    public void editCustomer(Customer customer) {
        customersDBDAO.updateCustomer(customer);
        System.out.println("customer successfully updated!");
    }

    public void deleteCustomer(int customerId) {
        customersDBDAO.deleteCustomer(customerId);
        System.out.println("customer successfully deleted!");
    }

    public ArrayList<Customer> getAllCustomers() {
        return customersDBDAO.getAllCustomers();
    }


    public Customer getCustomerById(int customerId) {
        return customersDBDAO.getOneCustomers(customerId);
    }

}
