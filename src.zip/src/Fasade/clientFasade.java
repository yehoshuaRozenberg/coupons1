package Fasade;

import DBDAO.CompanysDBDAO;
import DBDAO.CouponsDBDAO;
import DBDAO.CustomersDBDAO;
import Interfaces.CompanysDAO;
import Interfaces.CouponsDAO;
import Interfaces.CustomersDAO;

public abstract class clientFasade {
    protected CompanysDAO companysDAO;
    protected CustomersDAO customersDAO;
    protected CouponsDAO couponsDAO;

    public abstract boolean logIn(String email,String password);



    /*public void logIn (String name, String password,clientTipe clientTipe) {
        if (LoginManager.getInstance().logIn(name, password, clientTipe)) {
            switch (clientTipe){
        case Administrator:
            AdminFasade adminFasade=new AdminFasade(name);
            break;
        case Company:
            CompanyFasade companyFasade= new CompanyFasade(name);
            break;
        case Customer:
            CustomerFasade customerFasade= new CustomerFasade(name);
            break;
        default:
            break;
    }
    }else System.out.println("wrong details");


    }*/
}
