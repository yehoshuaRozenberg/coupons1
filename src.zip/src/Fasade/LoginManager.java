package Fasade;

import SQL.ConnectionPool;
import SQL.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginManager {
    private static LoginManager instance = null;


    //    private static String LOG_IN = "SELECT EXISTS (SELECT 1 FROM `couponsDB`.zz WHERE name =? and password=? limit 1 );";

    private LoginManager() {
    }

    public static LoginManager getInstance() {
        if (instance == null) {
            synchronized (LoginManager.class) {
                if (instance == null) {
                    instance = new LoginManager();
                }
            }
        }
        return instance;
    }

    /*private boolean logInChek(String email, String password, clientTipe clientTipe) {
        boolean res = false;
        if (clientTipe.equals(Fasade.clientTipe.Administrator)) {
            if (email.equals(EMAIL) && password.equals(PASSWORD)) {
                res = true;
            }
        } else {
            String LOG_IN = "SELECT EXISTS (SELECT 1 FROM `couponsDB`.Table WHERE email =? and password=? limit 1) ;";
            String log = LOG_IN.replaceFirst("Table", String.valueOf(clientTipe));
            Connection connection = null;
            try {
                connection = ConnectionPool.getInstance().getConnection();
                PreparedStatement statement = connection.prepareStatement(log);
                statement.setString(1, email);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    if (resultSet.getInt(1) != 0) {
                        res = true;
                    }
                }
            } catch (InterruptedException e) {
                System.out.println("error" + e);
                ;
            } catch (SQLException err) {
                System.out.println("Error" + err);
                ;
            } finally {
                try {
                    ConnectionPool.getInstance().returnConnection(connection);
                } catch (SQLException err) {
                    System.out.println("Error in finally:" + err.getMessage());
                }
            }
        }
        return res;
    }
*/

    public clientFasade logIn(String email, String password, clientTipe clientTipe) {
        switch (clientTipe) {
            case Administrator:
                AdminFasade adminFasade = new AdminFasade();
                if (adminFasade.logIn(email, password)) {
                    return adminFasade;
                } else System.out.println("wrong email or password");return null;
            case Companies:
                CompanyFasade companyFasade= new CompanyFasade();
                if (companyFasade.logIn(email, password)) {
                    return companyFasade;
                } else System.out.println("wrong email or password");return null;
            case Customers:
                CustomerFasade customerFasade= new CustomerFasade();
                if (customerFasade.logIn(email, password)) {
                    return customerFasade;
                } else System.out.println("wrong email or password");return null;
            default:
                System.out.println("wrong details");
                break;
        }
        return null;
}
}
