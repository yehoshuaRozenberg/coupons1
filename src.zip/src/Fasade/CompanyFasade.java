package Fasade;

import Beans.Catagory;
import Beans.Company;
import Beans.Coupon;
import DBDAO.CompanysDBDAO;
import DBDAO.CouponsDBDAO;
import DBDAO.CustomersDBDAO;
import SQL.DBUtils;

import java.util.ArrayList;

public class CompanyFasade extends clientFasade {
    private int id;
    private CompanysDBDAO companysDBDAO=new CompanysDBDAO();
    private CouponsDBDAO couponsDBDAO=new CouponsDBDAO();

    public CompanyFasade() {
    }

    public boolean logIn(String email, String password) {
        if (DBUtils.logInChek(email, password, "companies")) {
            this.id = DBUtils.getIdByEmail("companies", email);
            return true;
        } else return false;
    }

    public void addNewCoupon(Coupon coupon) {
        couponsDBDAO.addCoupon(coupon);
        System.out.println("coupon successfully added");
    }

    public void updateCoupon(Coupon coupon) {
        couponsDBDAO.updateCoupon(coupon);
        System.out.println("coupon successfully updated");
    }

    public void deleteCoupon(int id) {
        couponsDBDAO.deleteCoupon(id);
        System.out.println("coupon successfully deleted");
    }

    public ArrayList<Coupon> getAllCouponsOfCompany(){

        return couponsDBDAO.getAllCoupons(this.id);
    }

    public ArrayList<Coupon> getAllCouponsByCatagory (Catagory catagory){
      return couponsDBDAO.getAllCouponsByCompanyAndCategory(this.id,catagory.ordinal());
    }

    public ArrayList<Coupon> getAllCouponsUntilPrice(double maxPrice){
        return couponsDBDAO.getAllCouponsByCompanyAndPrice(this.id,maxPrice);
    }

    public Company getCompanyDetails() {
        return companysDBDAO.getOneCompany(id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
