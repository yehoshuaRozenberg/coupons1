package Fasade;

public enum clientTipe {
    Administrator,
    Companies,
    Customers
}

