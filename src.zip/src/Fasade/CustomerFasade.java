package Fasade;

import Beans.Catagory;
import Beans.Coupon;
import Beans.Customer;
import DBDAO.CouponsDBDAO;
import DBDAO.CustomersDBDAO;
import SQL.DBUtils;

import java.util.ArrayList;

public class CustomerFasade extends clientFasade {
    private int id;
    private CustomersDBDAO customersDBDAO = new CustomersDBDAO();
    private CouponsDBDAO couponsDBDAO = new CouponsDBDAO();

    public CustomerFasade() {
    }

    public boolean logIn(String email, String password) {
        if (DBUtils.logInChek(email, password, "customers")) {
            this.id = DBUtils.getIdByEmail("customers", email);
            return true;
        } else return false;
    }

    public void purchaseCoupon(Coupon coupon) {
        //if (!companysDBDAO.isCompanyExists(company.getName(), company.getEmail())) {
        //    companysDBDAO.addCompany(company);

       // if (customersDBDAO.isCustomerExistsById(this.id)){
         //   if ()
      //  }

        couponsDBDAO.addCouponPurchase(this.id,coupon.getId());
        System.out.println("purchase complited");
        //todo לא ניתן לרכוש את אותו הקופון יותר מפעם אחת.
        // o לא ניתן לרכוש את הקופון אם הכמות שלו היא 0.
        // לא ניתן לרכוש את הקופון אם תאריך התפוגה שלו כבר הגיעo
        // לאחר הרכישה יש להוריד את הכמות במלאי של הקופון ב-1
    }

    public ArrayList<Coupon> getAllCouponsPurchased (){
        return couponsDBDAO.getAllCouponsByCustomer(this.id);
    }

    public ArrayList<Coupon> getCouponsPurchasedByCategory(Catagory catagory){
      return couponsDBDAO.getAllCouponsByCompanyAndCategory(this.id,catagory.ordinal());
    }

    public ArrayList<Coupon> getCouponsPurchasedUntilPrice(double maxPrice){
        return couponsDBDAO.getAllCouponsByCompanyAndPrice(this.id,maxPrice);
    }

    public Customer getCustomerDetails() {
        return customersDBDAO.getOneCustomers(id);
    }


}
