package DBDAO;

import Beans.Catagory;
import Beans.Coupon;
import Interfaces.CouponsDAO;
import SQL.ConnectionPool;
import SQL.DBUtils;
import SQL.NewDBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class CouponsDBDAO implements CouponsDAO {
    private static final String ADD_COUPON = "INSERT INTO `couponsDB`.`coupons` (`ID_COMPANY`,`iD_CATEGORY`,`title`,`DESCRIPTION`,`START_DATE`,`END_DATE`,`AMOUNT`,`PRICE`,`IMAGE`) VALUES (?,?,?,?,?,?,?,?,?)";
    private static final String UPDATE_COUPON = "UPDATE `couponsDB`.`coupons` set  `ID_COMPANY`=?, `iD_CATEGORY`=?, `title`=?, `DESCRIPTION`=? ,`START_DATE`=? , `END_DATE`=? , `AMOUNT`=? , `PRICE`=? , `IMAGE`=? WHERE id=?";
    private static final String DELETE_COUPON = "DELETE FROM `couponsDB`.`coupons` where id=?";
    private static final String GET_ALL_COUPONS_BY_COMPANY = "SELECT * FROM `couponsDB`.`coupons` WHERE id_company=?";
    private static final String GET_ALL_COUPONS_BY_CUSTOMER = "SELECT * FROM `couponsDB`.`coupons` inner join `couponsDB`.`customers_vs_coupons` on `couponsDB`.`customers_vs_coupons`.`coupon_id` = `couponsDB`.`coupons`.`id` where `couponsDB`.`customers_vs_coupons`.`customer_id`=?";
    private static final String GET_ONE_COUPONS = "SELECT * FROM `couponsDB`.`coupons` WHERE id=?";
    private static final String ADD_COUPON_PURCHASE = "INSERT INTO `couponsDB`.`customers_vs_coupons` (`customer_id`,`coupon_id`) VALUES (?,?)";
    private static final String DELETE_COUPON_PURCHASE = "DELETE FROM `couponsDB`.`customers_vs_coupons` where coupon_id=? and customer_id=?";
    private static final String GET_COUPONS_BY_COMPANY_AND_CATEGORY = "SELECT * FROM `couponsDB`.`coupons` WHERE ID_COMPANY=? and iD_CATEGORY=?";
    private static final String GET_COUPONS_BY_COMPANY_UNTIL_PRICE = "SELECT * FROM `couponsDB`.`coupons` WHERE ID_COMPANY=? and price<=?";
    private static final String GET_COUPONS_BY_CUSTOMER_AND_CATEGORY = "SELECT * FROM `couponsDB`.`customers_vs_coupons` inner join `couponsDB`.`coupons` where `couponsDB`.`customers_vs_coupons`.`customer_id`=? and `couponsDB`.`coupons`.`id_category`=?";
    private static final String GET_COUPONS_BY_CUSTOMER_UNTIL_PRICE = "SELECT * FROM `couponsDB`.`customers_vs_coupons` inner join `couponsDB`.`coupons` where `couponsDB`.`customers_vs_coupons`.`customer_id`=? and `couponsDB`.`coupons`.`price`<=?";
    //connection to the data base
    Connection connection;


    public CouponsDBDAO() {
        try {
            ConnectionPool.getInstance();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void addCoupon(Coupon coupon) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, coupon.getCompanyID());
        params.put(2, coupon.getCatagory().ordinal());
        params.put(3, coupon.getTitle());
        params.put(4, coupon.getDescription());
        params.put(5, coupon.getStartDate());
        params.put(6, coupon.getEndDate());
        params.put(7, coupon.getAmount());
        params.put(8, coupon.getPrice());
        params.put(9, coupon.getImage());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(ADD_COUPON, params));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void updateCoupon(Coupon coupon) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, coupon.getCompanyID());
        params.put(2, coupon.getCatagory().ordinal());
        params.put(3, coupon.getTitle());
        params.put(4, coupon.getDescription());
        params.put(5, coupon.getStartDate());
        params.put(6, coupon.getEndDate());
        params.put(7, coupon.getAmount());
        params.put(8, coupon.getPrice());
        params.put(9, coupon.getImage());
        params.put(10, coupon.getId());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(UPDATE_COUPON, params));
        } catch (SQLException | InterruptedException err) {
            System.out.println("error" + err);
        }
        /*
        try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(UPDATE_COUPON);
            statement.setInt(1,coupon.getCompanyID());
            statement.setString(2,coupon .getTitle());
            //statement.setInt(3, coupon.getCategory());
            statement.setString(3, coupon.getDescription());
            statement.setDate(4, (Date.valueOf(coupon.getStartDate().toString())));
            statement.setDate(5, (Date) coupon.getEndDate());
            statement.setInt(6, coupon.getAmount());
            statement.setDouble(7,  coupon.getPrice());
            statement.setString(8, coupon.getImage());
            statement.setInt(9,coupon.getId());
            statement.execute();

        } catch (InterruptedException | SQLException err) {
            System.out.println("sql update coupon error: " + err);

        } finally {
            ConnectionPool.getInstance().returnConnection(connection);
        }*/

    }

    @Override
    public void deleteCoupon(int id) {
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareIntStatement(DELETE_COUPON, id));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


/*
    public static Catagory findCatagory(int num) {
        return num == Catagory.FOOD.ordinal() ? Catagory.FOOD :
                num == Catagory.ELECTRICITY.ordinal() ? Catagory.ELECTRICITY :
                        num == Catagory.RESTRAURANT.ordinal() ? Catagory.RESTRAURANT :
                                num == Catagory.VACATION.ordinal() ? Catagory.VACATION : null;
    }
*/

    @Override
    public ArrayList<Coupon> getAllCoupons(int id) {
        ArrayList<Coupon> coupons = null;
        try {
            coupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareIntStatement(GET_ALL_COUPONS_BY_COMPANY, id)));
        } catch (SQLException | InterruptedException err) {
            System.out.println("error:" + err);
        }
        /*try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(GET_ALL_COUPONS_BY_COMPANY);
            statement.setInt(1, 3);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Coupon coupon = new Coupon(resultSet.getInt(1), resultSet.getInt(2), Catagory.values()[(resultSet.getInt(3))], resultSet.getString(4), resultSet.getString(5), resultSet.getDate(6), resultSet.getDate(7), resultSet.getInt(8), resultSet.getDouble(9), resultSet.getString(10));
                coupons.add(coupon);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }*/    //////////////////////////////////******if want this metod need to write finnaly return connection

        return coupons;
    }


    @Override
    public Coupon getOneCoupon(int id) {
        Coupon coupon = null;
        try {
            ResultSet resultSet = NewDBUtils.runStatmentGetResult(NewDBUtils.prepareIntStatement(GET_ONE_COUPONS, id));
            while (resultSet.next())
                coupon = new Coupon(resultSet.getInt(1), Catagory.values()[resultSet.getInt(2)], resultSet.getString(3), resultSet.getString(4), resultSet.getDate(5), resultSet.getDate(6), resultSet.getInt(7), resultSet.getDouble(8), resultSet.getString(9));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coupon;
    }

        /*try {
            coupon = DBUtils.getFromDB(id ,GET_ONE_COUPONS);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return coupon;
}*/

    @Override
    public void addCouponPurchase(int customerId, int couponId) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1,customerId);
        params.put(2, couponId);
        try {
            //NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(ADD_COUPON_PURCHASE, params));
            DBUtils.runBetterQuery(ADD_COUPON_PURCHASE, params);
        } catch (SQLException  /*|InterruptedException*/ err) {
            System.out.println("error" + err);
        }

        /*try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(ADD_COUPON_PURCHASE);
            statement.setInt(1, customerId);
            statement.setInt(2,couponId);
            statement.execute();
            System.out.println("coupon successfully added");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
*/
    }

    @Override
    public void deleteCouponPurchase(int customerId, int couponId) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, couponId);
        params.put(2, customerId);
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(DELETE_COUPON_PURCHASE, params));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

       /* try {
            connection = ConnectionPool.getInstance().getConnection();
            PreparedStatement statement = connection.prepareStatement(DELETE_COUPON_PURCHASE);
            statement.setInt(1, couponId);
            statement.execute();
            System.out.println("coupon successfully deleted");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }*/

    }

    ///from here use neu dbutils

    public ArrayList<Coupon> getAllCouponsByCustomer(int id) {
        ArrayList<Coupon> coupons = null;
        try {
            coupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareIntStatement(GET_ALL_COUPONS_BY_CUSTOMER, id)));
        } catch (SQLException | InterruptedException err) {
            System.out.println("error:" + err);
        }
        return coupons;
    }

    public ArrayList<Coupon> getAllCouponsByCompanyAndCategory(int companyId, int num) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, companyId);
        params.put(2, num);
        ArrayList<Coupon> cupons = null;
        try {
            cupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareMapStatement(GET_COUPONS_BY_COMPANY_AND_CATEGORY, params)));
        } catch (InterruptedException | SQLException e) {
            System.out.println("error in sql: " + e);
        }
        return cupons;
    }

    /*
            try {
                DBUtils.runBetterQuery(GET_COUPONS_BY_COMPANY_AND_CATEGORY, params);
            } catch (SQLException err) {
                System.out.println("error" + err);
            }

            //String get = GET_ALL_COUPONS_BY_TABLE_AND_CATEGORY.replaceAll("Table", table).replaceAll("Field", field);
            ArrayList<Coupon> coupons = new ArrayList<>();
            try {
                connection = ConnectionPool.getInstance().getConnection();
                PreparedStatement statement = connection.prepareStatement("get");
                statement.setInt(1, companyId);
                statement.setDouble(2,num);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    Coupon coupon = new Coupon(resultSet.getInt(1), resultSet.getInt(2), Catagory.values()[resultSet.getInt(3)], resultSet.getString(4), resultSet.getString(5), resultSet.getDate(6), resultSet.getDate(7), resultSet.getInt(8), resultSet.getDouble(9), resultSet.getString(10));
                    coupons.add(coupon);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            return coupons;
        }
    */
    public ArrayList<Coupon> getAllCouponsByCompanyAndPrice(int id, double num) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, id);
        params.put(2, num);
        ArrayList<Coupon> cupons = null;
        try {
            cupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareMapStatement(GET_COUPONS_BY_COMPANY_UNTIL_PRICE, params)));
        } catch (InterruptedException | SQLException e) {
            System.out.println("error in sql: " + e);
        }
        return cupons;
    }

    public ArrayList<Coupon> getAllCouponsByIdAndCategory(int id, int num) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, id);
        params.put(2, num);
        ArrayList<Coupon> cupons = null;
        try {
            cupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareMapStatement(GET_COUPONS_BY_CUSTOMER_AND_CATEGORY, params)));
        } catch (InterruptedException | SQLException e) {
            System.out.println("error in sql: " + e);
        }
        return cupons;
    }

    public ArrayList<Coupon> getAllCouponsByIdAndPrice(int id, double num) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, id);
        params.put(2, num);
        ArrayList<Coupon> cupons = null;
        try {
            cupons = DBDAO_Utils.buildCuponArrayFromResult(NewDBUtils.runStatmentGetResult(
                    NewDBUtils.prepareMapStatement(GET_COUPONS_BY_CUSTOMER_UNTIL_PRICE, params)));
        } catch (InterruptedException | SQLException e) {
            System.out.println("error in sql: " + e);
        }
        return cupons;
    }

}
