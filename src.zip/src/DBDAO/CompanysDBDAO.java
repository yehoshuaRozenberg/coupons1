package DBDAO;

import Beans.Company;
import Interfaces.CompanysDAO;
import SQL.ConnectionPool;
import SQL.DBUtils;
import SQL.NewDBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CompanysDBDAO implements CompanysDAO {
    private static final String ADD_COMPANY = "INSERT INTO `couponsDB`.`companies` (`name`,`email`,`password`) VALUES (?,?,?)";
    private static final String UPDATE_COMPANY = "UPDATE `couponsDB`.`companies` SET `email`=?,`password`=? WHERE id=?";
    private static final String GET_ONE_COMPANY_BY_ID = "SELECT * FROM `couponsDB`.`companies` WHERE  `id`= ?";
    private static final String GET_ALL_COMPANY = "SELECT * FROM `couponsDB`.`companies`";
    private static final String DELETE_BY_ID = "DELETE FROM `couponsDB`.`companies` where id=?";
    private static final String IS_EXISTS_NAME = "SELECT EXISTS(SELECT 1 FROM couponsDB.companies WHERE name =? LIMIT 1)";
    private static final String IS_EXISTS_EMAIL = "SELECT EXISTS(SELECT 1 FROM couponsDB.companies WHERE email =? LIMIT 1)";

    private ConnectionPool connection;

    @Override
    public boolean isCompanyExists(String name, String email) {
        boolean res = true;
        try {
            if (!DBDAO_Utils.booleanFromResult(NewDBUtils.runStatmentGetResult(NewDBUtils.prepareStringStatement(IS_EXISTS_NAME,name)))&&
            !DBDAO_Utils.booleanFromResult(NewDBUtils.runStatmentGetResult(NewDBUtils.prepareStringStatement(IS_EXISTS_EMAIL,email))))
            res =false;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return res;
    }

    @Override
    public void addCompany(Company company) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, company.getName());
        params.put(2, company.getEmail());
        params.put(3, company.getPassword());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(ADD_COMPANY,params));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public void updateCompany(Company company) {
        //todo: bonus: isCompany email Exists();
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, company.getEmail());
        params.put(2, company.getPassword());
        params.put(3, company.getId());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(UPDATE_COMPANY,params));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public void deleteCompany(int id) {
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareIntStatement(DELETE_BY_ID,id));
        } catch (SQLException  | InterruptedException e) {
            e.printStackTrace();
        }
        DBUtils.deleteById(id, DELETE_BY_ID);
    }



    @Override
    public ArrayList<Company> getAllCompanys() {
        ArrayList<Company> companies = new ArrayList<>();
        ResultSet resultSet;
        try {
            resultSet = NewDBUtils.runSimpleQueryGetResult(GET_ALL_COMPANY);
            while (resultSet.next()) {
                Company company = new Company(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
                company.setId(resultSet.getInt(1)); //todo: לבדוק האם צריך להכניס לתוך השורה למעלה, אן שעדיף שלא יהיה קונסטרקטור שמקבל  איי די
                companies.add(company);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return companies;
    }

    @Override
    public Company getOneCompany(int id) {
        Company company = null;
        ResultSet resultSet;
        try {
            resultSet = NewDBUtils.runStatmentGetResult(NewDBUtils.prepareIntStatement(GET_ONE_COMPANY_BY_ID, id));
            while (resultSet.next())
               company = new Company(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
        return company;
    }


}
