package DBDAO;

import Beans.Catagory;
import Beans.Coupon;
import SQL.ConnectionPool;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBDAO_Utils {
    public static ArrayList<Coupon> buildCuponArrayFromResult(ResultSet resultSet) throws SQLException {
        ArrayList<Coupon> coupons = new ArrayList<>();
        //ResultSet resultSet1 = resultSet;
        //System.out.println(resultSet);
        while (resultSet.next()) {
            //Coupon coupon = new Coupon(resultSet.getInt(1), resultSet.getInt(2), Catagory.values()[(resultSet.getInt(3))], resultSet.getString(4), resultSet.getString(5), resultSet.getDate(6), resultSet.getDate(7), resultSet.getInt(8), resultSet.getDouble(9), resultSet.getString(10));
            Coupon coupon = new Coupon(/*resultSet.getInt(1),*/ resultSet.getInt(2), Catagory.values()[(resultSet.getInt(3))], resultSet.getString(4), resultSet.getString(5), resultSet.getDate(6), resultSet.getDate(7), resultSet.getInt(8), resultSet.getDouble(9), resultSet.getString(10));
            coupon.setId(resultSet.getInt(1)); //todo find why by customer getting twice
            coupons.add(coupon);
        }
        return coupons;

    }

    public static boolean booleanFromResult(ResultSet resultSet) throws SQLException {
        boolean res = false;
        ResultSet resultSet1 = resultSet;
        while (resultSet1.next()) {
            if (resultSet.getInt(1) != 0) {
                res = true;
            }
        }
        return res;
    }

    public static int intFromResult(ResultSet resultSet) throws SQLException {
        int res = 0;
        //ResultSet resultSet1 =resultSet;
        while (resultSet.next()) {
            res = resultSet.getInt(1);
        }
        return res;
    }

}
