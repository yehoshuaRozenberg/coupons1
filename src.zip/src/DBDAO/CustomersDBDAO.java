package DBDAO;

import Beans.Company;
import Beans.Customer;
import Interfaces.CustomersDAO;
import SQL.ConnectionPool;
import SQL.DBUtils;
import SQL.NewDBUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class CustomersDBDAO implements CustomersDAO {
    private static final String ADD_CUSTOMER = "INSERT INTO `couponsDB`.`customers` (`first_name`,`last_name`,`email`,`password`) VALUES (?,?,?,?)";
    private static final String UPDATE_CUSTOMER = "UPDATE `couponsDB`.`customers` SET `first_name`=? , `last_name`=? ,`email`=?,`password`=? WHERE id=?";
    private static final String GET_ONE_CUSTOMER_BY_ID = "SELECT * FROM `couponsDB`.`customers` WHERE  `id`= ?";
    private static final String GET_ALL_CUSTOMERS = "SELECT * FROM `couponsDB`.`customers`";
    private static final String DELETE_BY_ID = "DELETE FROM `couponsDB`.`customers` where id=?";
    private static final String IS_EXISTS = "SELECT EXISTS(SELECT 1 FROM couponsDB.customers WHERE email =? LIMIT 1)";
    private static final String IS_EXISTS_BY_ID = "SELECT EXISTS(SELECT 1 FROM couponsDB.customers_vs_coupons WHERE customer_id =? LIMIT 1)";

    private ConnectionPool connection;



    public boolean isCustomerExistsById(int id) {
        boolean res = true;
        try {
            if (!DBDAO_Utils.booleanFromResult(NewDBUtils.runStatmentGetResult(NewDBUtils.prepareIntStatement(IS_EXISTS, id)))) {
                res = false;
            }
        } catch (SQLException | InterruptedException e) {
            System.out.println("error: " + e);
        }
        return res;
    }


    @Override
    public boolean isCustomerExists(String email, String password) {
        boolean res = true;
        try {
            if (!DBDAO_Utils.booleanFromResult(NewDBUtils.runStatmentGetResult(NewDBUtils.prepareStringStatement(IS_EXISTS, email)))) {
                res = false;
            }
        } catch (SQLException | InterruptedException e) {
            System.out.println("error: " + e);
        }
        return res;
    }


    @Override
    public void addCustomer(Customer customer) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, customer.getFirstName());
        params.put(2, customer.getLastName());
        params.put(3, customer.getEmail());
        params.put(4, customer.getPassword());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(ADD_CUSTOMER, params));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void updateCustomer(Customer customer) {
        Map<Integer, Object> params = new LinkedHashMap<>();
        params.put(1, customer.getFirstName());
        params.put(2, customer.getLastName());
        params.put(3, customer.getEmail());
        params.put(4, customer.getPassword());
        params.put(5, customer.getId());
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareMapStatement(ADD_CUSTOMER, params));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void deleteCustomer(int id) {
        try {
            NewDBUtils.runStatment(NewDBUtils.prepareIntStatement(DELETE_BY_ID, id));
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public ArrayList<Customer> getAllCustomers() {    //todo: fix this metod
        ArrayList<Customer> customers = new ArrayList<>();
        ResultSet resultSet;
        try {
            resultSet= NewDBUtils.runSimpleQueryGetResult(GET_ALL_CUSTOMERS);
            while (resultSet.next()) {
                Customer customer = new Customer(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5));
                customer.setId(resultSet.getInt(1));
                customers.add(customer);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return customers;
    }

    @Override
    public Customer getOneCustomers(int id) {
        Customer customer = null;
        ResultSet resultSet;
        try {
            resultSet = NewDBUtils.runStatmentGetResult(NewDBUtils.prepareIntStatement(GET_ONE_CUSTOMER_BY_ID, id));
            while (resultSet.next()) {
                customer = new Customer(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5));
                customer.setId(resultSet.getInt(1));
            }
        } catch (SQLException | InterruptedException throwables) {
            throwables.printStackTrace();
        }
        return customer;
    }

}

